package com.example.PatientandMedcineRepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientandMedcineRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
